package com.omargroup.movies_thyme.model;


import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "movie_cast")
@AllArgsConstructor
@Getter
@Setter
@ToString
public class MovieCast {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    @JoinColumn(name = "movie_id", nullable = false)
    private Movie movie;

    @ManyToOne
    @JoinColumn(name = "actor_id", nullable = false)
    private Person person;

    @Column(name = "role")
    private String role; // Actor or Director role

    // Constructors
    public MovieCast() {}

    public MovieCast(Movie movie, Person person, String role) {
        this.movie = movie;
        this.person = person;
        this.role = role;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Movie getMovie() {
        return movie;
    }

    public void setMovie(Movie movie) {
        this.movie = movie;
    }

    public Person getPerson() {
        return person;
    }

    public void setPerson(Person person) {
        this.person = person;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}