package com.omargroup.movies_thyme.controller;

import com.omargroup.movies_thyme.model.Genre;
import com.omargroup.movies_thyme.service.GenreService;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/genre")
public class GenreController {
    private final GenreService genreService;

    public GenreController(GenreService genreService) {
        this.genreService = genreService;
    }

    @GetMapping
    public List<Genre> getAllGenres(){
        return genreService.findAll();
    }

    @GetMapping("/{genreId}")
    public Genre getAllGenres(@PathVariable Long genreId){
        return genreService.findById(genreId);
    }


    @PostMapping
    public Genre getAllGenres(@RequestBody Genre genre){
        return genreService.createGenre(genre);
    }






}
