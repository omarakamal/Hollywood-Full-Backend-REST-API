package com.omargroup.movies_thyme.controller;

import com.omargroup.movies_thyme.model.Movie;
import com.omargroup.movies_thyme.model.MovieCast;
import com.omargroup.movies_thyme.model.Person;
import com.omargroup.movies_thyme.service.MovieCastService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/actors")
public class MovieCastController {
    private final MovieCastService movieCastService;

    public MovieCastController(MovieCastService movieCastService) {
        this.movieCastService = movieCastService;
    }

    @GetMapping("/actors-in-movies")
    public List<Person> allActorsPerMovie(Long movieId){
        return movieCastService.getAllActorsForMovie(movieId);
    }

    @GetMapping("/movies-for-actor")
    public List<Movie> allMoviesPerActor(Long personId){
        return movieCastService.getAllMoviesForActor(personId);
    }

    @PostMapping("/actor-to-movie/{movieId}/{actorId}")
    public MovieCast addActorToMovie(@PathVariable Long movieId, @PathVariable Long actorId, @RequestBody MovieCast movieCast){
        return movieCastService.addActorToMovie(movieId,actorId,movieCast);
    }
}
