//package com.omargroup.movies_thyme.controller;
//
//import com.omargroup.movies_thyme.model.Movie;
//import com.omargroup.movies_thyme.service.MovieService;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@Controller
//@RequestMapping("/movies")
//public class MovieControllerV2 {
//    private final MovieService movieService;
//
//    public MovieControllerV2(MovieService movieService) {
//        this.movieService = movieService;
//    }
//
//    @GetMapping
//    public String listMovies(Model model){
//        List<Movie> movies = movieService.findAll();
//
//        model.addAttribute("movies",movies);
//
//        return "movies/list-movies";
//    }
//
//    @GetMapping("/create")
//    public String createMovie(Model model){
//
//        model.addAttribute("movie",new Movie());
//
//        return "movies/create-movie";
//    }
//
//    @PostMapping
//    public String saveMovie(@ModelAttribute Movie movie){
//        System.out.println(movie);
//        movieService.save(movie);
//
//
//        return "redirect:/movies";
//    }
//
//
//    @GetMapping("/update")
//    public String updateMovie(@RequestParam("movieId") Long movieId, Model model){
//        Movie movie = movieService.findById(movieId);
//
//        model.addAttribute("movie",movie);
//
//        return "movies/create-movie";
//    }
//
//
//    @DeleteMapping
//    public String delete(@RequestParam("movieId") Long movieId){
//
//        movieService.deleteById(movieId);
//
//        return "redirect:/movies";
//    }
//}
