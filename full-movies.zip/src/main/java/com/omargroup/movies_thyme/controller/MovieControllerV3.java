package com.omargroup.movies_thyme.controller;

import com.omargroup.movies_thyme.model.Movie;
import com.omargroup.movies_thyme.service.MovieService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;



@RestController
@RequestMapping("/api/movies")
public class MovieControllerV3 {
    private final MovieService movieService;


    public MovieControllerV3(MovieService movieService) {
        this.movieService = movieService;
    }

    @GetMapping
    public List<Movie> listMovies(){


        return movieService.findAll();
    }

    @GetMapping("/{movieId}")
    public Movie getMovieById(@PathVariable Long movieId){
        return movieService.findById(movieId);
    }

    @PutMapping("/{movieId}")
    public Movie updateMovie(@PathVariable Long movieId, @RequestBody Movie movie){

        return movieService.updateMovieById(movieId,movie);
    }




    @PostMapping("/{genreId}/{directorId}")
    public Movie saveMovie(@RequestBody Movie movie, @PathVariable Long genreId, @PathVariable Long directorId){


        return movieService.createNewMovie(movie,genreId,directorId);
    }



}
