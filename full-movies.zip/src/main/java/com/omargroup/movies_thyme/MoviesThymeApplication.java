package com.omargroup.movies_thyme;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MoviesThymeApplication {

	public static void main(String[] args) {
		SpringApplication.run(MoviesThymeApplication.class, args);
	}

}
