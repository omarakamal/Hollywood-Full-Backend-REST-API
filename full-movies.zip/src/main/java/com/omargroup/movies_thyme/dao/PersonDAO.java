package com.omargroup.movies_thyme.dao;

import com.omargroup.movies_thyme.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface PersonDAO extends JpaRepository<Person,Long> {

}
