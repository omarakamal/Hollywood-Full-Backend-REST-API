package com.omargroup.movies_thyme.dao;

import com.omargroup.movies_thyme.model.Movie;
import com.omargroup.movies_thyme.model.MovieCast;
import com.omargroup.movies_thyme.model.Person;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface MovieCastRepository extends JpaRepository<MovieCast, Long> {


    List<Movie> findMoviesByPersonPersonId(Long personId);

    List<Person> findActorsByMovieMovieId(Long movieId);


//    List<Movie> findAllByOrderByTitleAsc();



}
