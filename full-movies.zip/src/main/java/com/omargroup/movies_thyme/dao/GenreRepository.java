package com.omargroup.movies_thyme.dao;

import com.omargroup.movies_thyme.model.Genre;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface GenreRepository extends JpaRepository<Genre,Long> {
    Genre findByName(String categoryName);
}
