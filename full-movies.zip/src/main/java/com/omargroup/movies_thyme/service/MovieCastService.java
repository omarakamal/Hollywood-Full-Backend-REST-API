package com.omargroup.movies_thyme.service;

import com.omargroup.movies_thyme.dao.MovieCastRepository;
import com.omargroup.movies_thyme.dao.MovieRepository;
import com.omargroup.movies_thyme.dao.PersonDAO;
import com.omargroup.movies_thyme.exceptions.ResourceNotFoundException;
import com.omargroup.movies_thyme.model.Movie;
import com.omargroup.movies_thyme.model.MovieCast;
import com.omargroup.movies_thyme.model.Person;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MovieCastService {
    private final MovieCastRepository movieCastRepository;
    private final MovieRepository movieRepository;
    private final PersonDAO personDAO;
    private final MovieService movieService;
    private final PersonService personService;


    public MovieCastService(MovieCastRepository movieCastRepository, MovieRepository movieRepository, PersonDAO personDAO, MovieService movieService, PersonService personService) {
        this.movieCastRepository = movieCastRepository;
        this.movieRepository = movieRepository;
        this.personDAO = personDAO;
        this.movieService = movieService;
        this.personService = personService;
    }

    public List<Movie> getAllMoviesForActor(Long actorId){
        Person foundPerson = personDAO.findById(actorId).orElseThrow(()->new ResourceNotFoundException("Actor not available with this id: " + actorId));

        List<Movie> foundMovies = movieCastRepository.findMoviesByPersonPersonId(actorId);

        return foundMovies;

    }

    public List<Person> getAllActorsForMovie(Long movieId){
        Movie foundMovie = movieRepository.findById(movieId).orElseThrow(()->new ResourceNotFoundException("Movie not available with this id " + movieId));

        return movieCastRepository.findActorsByMovieMovieId(movieId);
    }


    public MovieCast addActorToMovie(Long movieId, Long actorId, MovieCast movieCast){
        Person foundActor = personService.getPersonById(actorId);
        Movie foundMovie = movieService.findById(movieId);

        movieCast.setMovie(foundMovie);
        movieCast.setPerson(foundActor);

        return movieCastRepository.save(movieCast);

    }

}
