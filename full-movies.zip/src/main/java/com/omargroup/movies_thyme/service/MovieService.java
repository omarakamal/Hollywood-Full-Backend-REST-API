package com.omargroup.movies_thyme.service;


import com.omargroup.movies_thyme.dao.GenreRepository;
import com.omargroup.movies_thyme.dao.MovieRepository;
import com.omargroup.movies_thyme.dao.PersonDAO;
import com.omargroup.movies_thyme.exceptions.ResourceNotFoundException;
import com.omargroup.movies_thyme.model.Genre;
import com.omargroup.movies_thyme.model.Movie;
import com.omargroup.movies_thyme.model.Person;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class MovieService {

    private MovieRepository movieRepository;
    private GenreRepository genreRepository;
    private PersonDAO personDAO;
    private final GenreService genreService;
    private final PersonService personService;


    public MovieService(MovieRepository movieRepository, GenreRepository genreRepository, PersonDAO personDAO, GenreService genreService, PersonService personService) {
        this.movieRepository = movieRepository;
        this.genreRepository = genreRepository;
        this.personDAO = personDAO;
        this.genreService = genreService;
        this.personService = personService;
    }


    public List<Movie> findAll() {
        return movieRepository.findAll();
    }

    public Movie findById(Long theId) {
        Optional<Movie> foundMovie = movieRepository.findById(theId);

        if(foundMovie.isEmpty()){
            throw new RuntimeException("No Employee Found with this id: " + theId);
        }
        return foundMovie.get();
    }

    public Movie createNewMovie(Movie movie, Long genreId,Long directorId) {
        System.out.println("Service calling create new movie");

        Person director = personService.getPersonById(directorId);
        System.out.println("found director: " + director);
        Genre genre = genreService.findById(genreId);
        System.out.println("found genre: " + genre);


        movie.setGenre(genre);
        movie.setDirector(director);
        System.out.println(movie);
        return movieRepository.save(movie);

    }

    public List<Movie> getMoviesByGenreId(Long genreId){
        Optional<Genre> genre = genreRepository.findById(genreId);

        if(genre.isPresent()){
            return movieRepository.findByGenreGenreId(genreId);
        }
        else{
            throw new ResourceNotFoundException("Category with Id: " +  genreId + " Not Found");
        }
    }

    public Movie updateMovieById(Long movieId, Movie newMovie){
        Movie foundMovie = movieRepository.findById(movieId)
                .orElseThrow(()-> new ResourceNotFoundException("No Movie with Id "+ movieId + " Matches"));
        Genre foundGenre = genreRepository.findById(newMovie.getGenre().getGenreId())
                .orElseThrow(()-> new ResourceNotFoundException("Genre Does Not Exist " + newMovie.getGenre().getGenreId() + " Matches"));

        Person foundDirector = personDAO.findById(newMovie.getDirector().getPersonId())
                .orElseThrow(()-> new ResourceNotFoundException("Director Does Not Exist " + newMovie.getGenre().getGenreId() + " Matches"));



        foundMovie.setTitle(newMovie.getTitle());
        foundMovie.setDirector(newMovie.getDirector());
        foundMovie.setDuration(newMovie.getDuration());
        foundMovie.setHasOscars(newMovie.isHasOscars());
        foundMovie.setRating(newMovie.getRating());
        foundMovie.setDescription(newMovie.getDescription());
        foundMovie.setReleaseYear(newMovie.getReleaseYear());
        foundMovie.setGenre(foundGenre);

        return movieRepository.save(foundMovie);
    }

    public void deleteMovieById(Long movieId) {

            Optional<Movie> movie = movieRepository.findById(movieId);
            Movie fetchedMovie = movie.orElseThrow(()-> new ResourceNotFoundException("Movie with id " + movieId + " does not exists"));
            movieRepository.deleteById(fetchedMovie.getMovieId());
    }



    public void deleteById(Long movieId) {
        movieRepository.deleteById(movieId);
    }

}
