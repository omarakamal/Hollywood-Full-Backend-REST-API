package com.omargroup.movies_thyme.service;

import com.omargroup.movies_thyme.dao.GenreRepository;
import com.omargroup.movies_thyme.exceptions.ResourceExistsException;
import com.omargroup.movies_thyme.exceptions.ResourceNotFoundException;
import com.omargroup.movies_thyme.model.Genre;
import lombok.AllArgsConstructor;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PutMapping;

import java.util.List;
import java.util.Optional;
@Service
public class GenreService {
    private final GenreRepository genreRepository;

    public GenreService(GenreRepository genreRepository) {
        this.genreRepository = genreRepository;
    }


    public List<Genre> findAll(){
        return genreRepository.findAll();
    }

    public Genre findById(Long genreId){
        Optional<Genre> foundGenre = genreRepository.findById(genreId);

        return foundGenre.orElseThrow(()-> new ResourceNotFoundException("Id Not Found"));
    }

    public Genre createGenre(Genre genre){

        Genre foundGenre = genreRepository.findByName(genre.getName());

        if(foundGenre != null){
            throw new ResourceExistsException("Genre with name " + genre.getName());
        }
        else{
            return genreRepository.save(genre);
        }
    }


    public Genre updateGenre(Long genreId, Genre genreObject) {
        System.out.println("service calling Genre Update ==>");
        Optional<Genre> foundGenre = genreRepository.findById(genreId);
        if (foundGenre.isPresent()) {
            if (genreObject.getName().equals(foundGenre.get().getName())) {
                System.out.println("Same");
                throw new ResourceExistsException("Genre " + foundGenre.get().getName() + " is already exists");
            } else {
                Genre updateCategory = genreRepository.findById(genreId).get();
                updateCategory.setName(genreObject.getName());
                return genreRepository.save(updateCategory);
            }
        } else {
            throw new ResourceExistsException("category with id " + genreId + " not found");
        }
    }


}
