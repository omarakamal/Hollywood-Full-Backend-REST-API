package com.omargroup.movies_thyme.service;

import com.omargroup.movies_thyme.dao.PersonDAO;
import com.omargroup.movies_thyme.exceptions.ResourceNotFoundException;
import com.omargroup.movies_thyme.model.Person;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PersonService {
    private final PersonDAO personDAO;


    public PersonService(PersonDAO personDAO) {
        this.personDAO = personDAO;
    }


//    create director
//    get all the directors
//    get all the movies directed by director
//    CRUD for director

    public Person createNewPerson(Person person){
       return personDAO.save(person);
    }

    public Person getPersonById(Long personId){
        return personDAO.findById(personId)
                .orElseThrow(()-> new ResourceNotFoundException("No person matches the id provided"));
    }

    public List<Person> getAllPeople(){
        return personDAO.findAll();
    }




}
